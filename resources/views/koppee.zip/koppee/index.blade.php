<html lang="id">

<head>
<meta charset="utf-8">
<title>UMKM Risoles - Resep Nikmat Sejak 2006</title>
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<meta content="UMKM Risoles, Risoles Mayo, Risoles Ragout, Risoles Frozen" name="keywords">
<meta content="Situs resmi UMKM Risoles. Kami menyajikan risoles premium dengan bahan pilihan dan resep warisan keluarga." name="description">

<!-- Favicon -->
<link href="{{ asset('assets/img/favicon.ico') }}" rel="icon">

<!-- Google Font -->
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;400&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">

<!-- Font Awesome -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

<!-- Libraries Stylesheet -->
<link href="{{ asset('assets/lib/owlcarousel/assets/owl.carousel.min.css') }}" rel="stylesheet">
<link href="{{ asset('assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css') }}" rel="stylesheet" />

<!-- Customized Bootstrap Stylesheet -->
<link href="{{ asset('assets/css/style.min.css') }}" rel="stylesheet">


</head>

<body>
<!-- Navbar Start -->
<div class="container-fluid p-0 nav-bar">
    <nav class="navbar navbar-expand-lg bg-none navbar-dark py-3">
        <a href="{{ url('/') }}" class="navbar-brand px-lg-4 m-0">
            <h1 class="m-0 display-4 text-uppercase text-white">UMKM</h1>
        </a>
        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
            <div class="navbar-nav ml-auto p-4">
                <a href="{{ url('/') }}" class="nav-item nav-link active">Beranda</a>
                <a href="{{ url('/about') }}" class="nav-item nav-link">Tentang Kami</a>
                <a href="{{ url('/service') }}" class="nav-item nav-link">Layanan</a>
                <a href="{{ url('/menu') }}" class="nav-item nav-link">Menu</a>
                
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Halaman</a>
                    <div class="dropdown-menu text-capitalize">
                        @auth
                            <a href="{{ route('reservation.index') }}" class="dropdown-item">Reservasi</a>
                        @else
                            <a href="{{ route('login') }}" class="dropdown-item">Reservasi</a>
                        @endauth
                        <a href="{{ url('/testimonial') }}" class="dropdown-item">Testimoni</a>
                    </div>
                </div>
                
                <a href="{{ url('/contact') }}" class="nav-item nav-link">Kontak</a>
            </div>
        </div>
    </nav>
</div>
<!-- Navbar End -->
<!-- Carousel Start -->
<div class="container-fluid p-0 mb-5">
    <div id="blog-carousel" class="carousel slide overlay-bottom" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img class="w-100" src="{{ asset('assets/img/carousel-1.jpg') }}" alt="Risoles UMKM">
                <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                    <h2 class="text-primary font-weight-medium m-0">Kami Telah Menyajikan</h2>
                    <h1 class="display-1 text-white m-0">Risoles</h1>
                    <h2 class="text-white m-0">* SEJAK 2006 *</h2>
                </div>
            </div>
            <div class="carousel-item">
                <img class="w-100" src="{{ asset('assets/img/carousel-2.jpg') }}" alt="Varian Risoles">
                <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                    <h2 class="text-primary font-weight-medium m-0">Cita Rasa Warisan</h2>
                    <h1 class="display-1 text-white m-0">Terbaik</h1>
                    <h2 class="text-white m-0">* KUALITAS PREMIUM *</h2>
                </div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#blog-carousel" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </a>
        <a class="carousel-control-next" href="#blog-carousel" data-slide="next">
            <span class="carousel-control-next-icon"></span>
        </a>
    </div>
</div>
<!-- Carousel End -->


<!-- About Start -->
<div class="container-fluid py-5">
    <div class="container">
        <div class="section-title">
            <h4 class="text-primary text-uppercase" style="letter-spacing: 5px;">Tentang Kami</h4>
            <h1 class="display-4">Resep Nikmat Sejak 2006</h1>
        </div>
        <div class="row">
            <div class="col-lg-4 py-0 py-lg-5">
                <h2 class="mb-3">Cerita Kami</h2>
                <h5 class="mb-3">Berawal dari dapur rumahan, kami hadir untuk menyajikan camilan berkualitas.</h5>
                <p>Sebagai bagian dari UMKM lokal, kami bangga dapat menghadirkan Risoles premium yang dibuat dengan bahan-bahan pilihan. Setiap gigitan adalah perpaduan sempurna antara kulit yang renyah dan isian yang melimpah, diolah dengan bumbu resep warisan keluarga.</p>
                @auth
                    <a href="{{ route('reservation.index') }}" class="btn btn-primary font-weight-bold py-2 px-4 mt-2">Pesan Sekarang</a>
                @else
                    <a href="{{ route('login') }}" class="btn btn-primary font-weight-bold py-2 px-4 mt-2">Pesan Sekarang</a>
                @endauth
            </div>
            <div class="col-lg-4 py-5 py-lg-0" style="min-height: 500px;">
                <div class="position-relative h-100">
                    <img class="position-absolute w-100 h-100" src="{{ asset('assets/img/about.png') }}" style="object-fit: cover;" alt="Tentang Risoles Kami">
                </div>
            </div>
            <div class="col-lg-4 py-0 py-lg-5">
                <h2 class="mb-3">Visi Kami</h2>
                <p>Menjadi UMKM terdepan yang mempopulerkan Risoles sebagai camilan favorit berkualitas tinggi, higienis, dan inovatif.</p>
                <h5 class="mb-3"><i class="fa fa-check text-primary mr-3"></i>Kualitas Bahan Terbaik & Halal</h5>
                <h5 class="mb-3"><i class="fa fa-check text-primary mr-3"></i>Higienis dan Tanpa Pengawet</h5>
                <h5 class="mb-3"><i class="fa fa-check text-primary mr-3"></i>Inovasi Varian Rasa (Mayo, Ragout, Smoked Beef)</h5>
                <a href="{{ url('/menu') }}" class="btn btn-primary font-weight-bold py-2 px-4 mt-2">Lihat Menu</a>
            </div>
        </div>
    </div>
</div>
<!-- About End -->


<!-- Service Start -->
<div class="container-fluid pt-5">
    <div class="container">
        <div class="section-title">
            <h4 class="text-primary text-uppercase" style="letter-spacing: 5px;">Layanan Kami</h4>
            <h1 class="display-4">Kualitas & Pelayanan</h1>
        </div>
        <div class="row">
            <div class="col-lg-6 mb-5">
                <div class="row align-items-center">
                    <div class="col-sm-5">
                        <img class="img-fluid mb-3 mb-sm-0" src="{{ asset('assets/img/service-1.jpg') }}" alt="Pengantaran Cepat Risoles">
                    </div>
                    <div class="col-sm-7">
                        <h4><i class="fa fa-truck service-icon"></i>Pengantaran Cepat</h4>
                        <p class="m-0">Pesanan Anda kami antar cepat dan aman, langsung ke depan pintu Anda.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 mb-5">
                <div class="row align-items-center">
                    <div class="col-sm-5">
                        <img class="img-fluid mb-3 mb-sm-0" src="{{ asset('assets/img/service-2.jpg') }}" alt="Bahan Pilihan Segar Risoles">
                    </div>
                    <div class="col-sm-7">
                        <h4><i class="fa fa-check service-icon"></i>Bahan Pilihan Segar</h4>
                        <p class="m-0">Kami hanya menggunakan bahan baku premium, sayuran segar, dan daging pilihan yang 100% halal.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 mb-5">
                <div class="row align-items-center">
                    <div class="col-sm-5">
                        <img class="img-fluid mb-3 mb-sm-0" src="{{ asset('assets/img/service-3.jpg') }}" alt="Kualitas Rasa Terbaik Risoles">
                    </div>
                    <div class="col-sm-7">
                        <h4><i class="fa fa-award service-icon"></i>Kualitas Rasa Terbaik</h4>
                        <p class="m-0">Diolah dengan resep warisan, menjamin cita rasa risoles yang gurih dan tak terlupakan.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 mb-5">
                <div class="row align-items-center">
                    <div class="col-sm-5">
                        <img class="img-fluid mb-3 mb-sm-0" src="{{ asset('assets/img/service-4.jpg') }}" alt="Pesan Online Mudah Risoles">
                    </div>
                    <div class="col-sm-7">
                        <h4><i class="fa fa-calendar-check service-icon"></i>Pesan Online Mudah</h4>
                        <p class="m-0">Pesan kapan saja untuk acara, kumpul keluarga, atau camilan harian Anda.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Service End -->


<!-- Offer Start -->
<div class="offer container-fluid my-5 py-5 text-center position-relative overlay-top overlay-bottom">
    <div class="container py-5">
        <h1 class="display-3 text-primary mt-3">PROMO 50%</h1>
        <h1 class="text-white mb-3">Penawaran Spesial Minggu Ini</h1>
        <h4 class="text-white font-weight-normal mb-4 pb-3">Hanya untuk pemesanan online minggu ini!</h4>
        <form class="form-inline justify-content-center mb-4">
            <div class="input-group">
                </div>
            </div>
        </form>
    </div>
</div>
<!-- Offer End -->


<!-- Menu Start -->
<div class="container-fluid pt-5">
    <div class="container">
        <div class="section-title">
            <h4 class="text-primary text-uppercase" style="letter-spacing: 5px;">Menu & Harga</h4>
            <h1 class="display-4">Pilihan Varian Risoles Kami</h1>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <h1 class="mb-5">Varian Gurih (Asin)</h1>
                <div class="row align-items-center mb-5">
                    <div class="col-4 col-sm-3">
                        <!-- Ganti 'menu-1.jpg' dengan foto Risol Mayo Anda -->
                        <img class="w-100 rounded-circle mb-3 mb-sm-0" src="{{ asset('assets/img/menu-1.jpg') }}" alt="Risol Mayo">
                        <h5 class="menu-price">7k</h5>
                    </div>
                    <div class="col-8 col-sm-9">
                        <h4>Risol Mayo</h4>
                        <p class="m-0">Perpaduan premium smoked beef (daging asap), telur rebus, dan saus mayones spesial kami yang lumer di mulut.</p>
                    </div>
                </div>
                <div class="row align-items-center mb-5">
                    <div class="col-4 col-sm-3">
                        <!-- Ganti 'menu-2.jpg' dengan foto Risol Ayam Anda -->
                        <img class="w-100 rounded-circle mb-3 mb-sm-0" src="{{ asset('assets/img/menu-2.jpg') }}" alt="Risol Ayam">
                        <h5 class="menu-price">6k</h5>
                    </div>
                    <div class="col-8 col-sm-9">
                        <h4>Risol Ayam</h4>
                        <p class="m-0">Isian suwiran ayam yang dimasak dengan bumbu gurih dan rempah-rempah pilihan. Enak dan mengenyangkan.</p>
                    </div>
                </div>
                <div class="row align-items-center mb-5">
                    <div class="col-4 col-sm-3">
                        <!-- Ganti 'menu-3.jpg' dengan foto Risol Ragout Anda -->
                        <img class="w-100 rounded-circle mb-3 mb-sm-0" src="{{ asset('assets/img/menu-3.jpg') }}" alt="Risol Ragout">
                        <h5 class="menu-price">5k</h5>
                    </div>
                    <div class="col-8 col-sm-9">
                        <h4>Risol Ragout</h4>
                        <p class="m-0">Resep warisan klasik. Isian ragout ayam dan sayuran (wortel, buncis) yang creamy dan gurih.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <h1 class="mb-5">Varian Frozen</h1>
                <div class="row align-items-center mb-5">
                    <div class="col-4 col-sm-3">
                        <!-- Ganti 'menu-1.jpg' dengan foto Risol Mayo Beku -->
                        <img class="w-100 rounded-circle mb-3 mb-sm-0" src="{{ asset('assets/img/menu-1.jpg') }}" alt="Risol Mayo Frozen">
                        <h5 class="menu-price">30k</h5>
                    </div>
                    <div class="col-8 col-sm-9">
                        <h4>Risol Mayo (isi 5)</h4>
                        <p class="m-0">Stok camilan lumer favorit Anda (isi 5 pcs). Siap digoreng kapan saja!</p>
                    </div>
                </div>
                <div class="row align-items-center mb-5">
                    <div class="col-4 col-sm-3">
                        <!-- Ganti 'menu-2.jpg' dengan foto Risol Ayam Beku -->
                        <img class="w-100 rounded-circle mb-3 mb-sm-0" src="{{ asset('assets/img/menu-2.jpg') }}" alt="Risol Ayam Frozen">
                        <h5 class="menu-price">25k</h5>
                    </div>
                    <div class="col-8 col-sm-9">
                        <h4>Risol Ayam (isi 5)</h4>
                        <p class="m-0">Camilan gurih dengan isian ayam (isi 5 pcs). Praktis untuk dinikmati bersama keluarga.</p>
                    </div>
                </div>
                <div class="row align-items-center mb-5">
                    <div class="col-4 col-sm-3">
                        <!-- Ganti 'menu-3.jpg' dengan foto Risol Ragout Beku -->
                        <img class="w-100 rounded-circle mb-3 mb-sm-0" src="{{ asset('assets/img/menu-3.jpg') }}" alt="Risol Ragout Frozen">
                        <h5 class="menu-price">20k</h5>
                    </div>
                    <div class="col-8 col-sm-9">
                        <h4>Risol Ragout (isi 5)</h4>
                        <p class="m-0">Resep ragout klasik kami (isi 5 pcs), kini dalam kemasan beku. Siap sedia di freezer Anda.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Menu End -->


<!-- Reservation Start -->
<div class="container-fluid my-5">
    <div class="container">
        <div class="reservation position-relative overlay-top overlay-bottom">
            <div class="row align-items-center">
                <div class="col-lg-6 my-5 my-lg-0">
                    <div class="p-5">
                        <div class="mb-4">
                            <h1 class="display-3 text-primary">DISKON 30%</h1>
                            <h1 class="text-white">Untuk Pesanan Online</h1>
                        </div>
                        <p class="text-white">Pesan risoles favorit Anda untuk acara spesial, rapat, atau camilan di rumah. Cukup isi form di samping dan kami akan siapkan pesanan Anda.</p>
                        <ul class="list-inline text-white m-0">
                            <li class="py-2"><i class="fa fa-check text-primary mr-3"></i>Pesanan disiapkan dadakan (Fresh)</li>
                            <li class="py-2"><i class="fa fa-check text-primary mr-3"></i>Bisa request jadwal antar</li>
                            <li class="py-2"><i class="fa fa-check text-primary mr-3"></i>Praktis dan tanpa repot</li>
                        </ul>
                    </div>
                </div>
             <div class="col-lg-6">
    <div class="text-center p-5 d-flex flex-column justify-content-center h-100" style="background: rgba(51, 33, 29, .85);">

        <div class="mb-3">
            <i class="fa fa-gift fa-4x text-primary"></i>
        </div>

        <h2 class="text-white font-weight-bold mb-2">Tertarik dengan promo ini?</h2>
        <p class="text-white-50 mb-4">Jangan sampai kehabisan slot diskon harian.</p>

        <a href="{{ route('reservation.index') }}" class="btn btn-primary text-white font-weight-bold py-3 px-5 shadow-lg rounded-pill">
            Buka Menu Reservasi <i class="fa fa-arrow-right ml-2"></i>
        </a>

    </div>
</div>
</div>
</div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Reservation End -->


<!-- Testimonial Start -->
<div class="container-fluid py-5">
    <div class="container">
        <div class="section-title">
            <h4 class="text-primary text-uppercase" style="letter-spacing: 5px;">Testimoni</h4>
            <h1 class="display-4">Kata Pelanggan Kami</h1>
        </div>
        <div class="owl-carousel testimonial-carousel">
            <div class="testimonial-item">
                <div class="d-flex align-items-center mb-3">
                    <!-- Ganti 'testimonial-1.jpg' dengan foto pelanggan Anda jika ada -->
                    <img class="img-fluid" src="{{ asset('assets/img/testimonial-1.jpg') }}" alt="Testimoni Pelanggan 1">
                    <div class="ml-3">
                        <h4>Indah</h4>
                        <i>Karyawan Swasta</i>
                    </div>
                </div>
                <p class="m-0">Risol mayo-nya juara! Kulitnya renyah, isinya lumer banget di mulut. Selalu jadi andalan buat camilan sore.</p>
            </div>
            <div class="testimonial-item">
                <div class="d-flex align-items-center mb-3">
                    <!-- Ganti 'testimonial-2.jpg' dengan foto pelanggan Anda jika ada -->
                    <img class="img-fluid" src="{{ asset('assets/img/testimonial-2.jpg') }}" alt="Testimoni Pelanggan 2">
                    <div class="ml-3">
                        <h4>Pangestu</h4>
                        <i>Mahasiswa</i>
                    </div>
                </div>
                <p class="m-0">Stok risol frozen-nya sangat praktis. Tinggal goreng, anak-anak di rumah langsung rebutan. Risoles ragout-nya gurih, isiannya pas.</p>
            </div>
            <div class="testimonial-item">
                <div class="d-flex align-items-center mb-3">
                    <!-- Ganti 'testimonial-3.jpg' dengan foto pelanggan Anda jika ada -->
                    <img class="img-fluid" src="{{ asset('assets/img/testimonial-3.jpg') }}" alt="Testimoni Pelanggan 3">
                    <div class="ml-3">
                        <h4>Rina</h4>
                        <i>Manajer Acara</i>
                    </div>
                </div>
                <p class="m-0">Pesan 5 box untuk acara rapat kantor. Layanannya cepat dan tepat waktu. Semua suka, rasanya premium dan ukurannya pas. Terima kasih!</p>
            </div>
            <div class="testimonial-item">
                <div class="d-flex align-items-center mb-3">
                    <!-- Ganti 'testimonial-4.jpg' dengan foto pelanggan Anda jika ada -->
                    <img class="img-fluid" src="{{ asset('assets/img/testimonial-4.jpg') }}" alt="Testimoni Pelanggan 4">
                    <div class="ml-3">
                        <h4>Manalu</h4>
                        <i>Mahasiswa</i>
                    </div>
                </div>
                <p class="m-0">Enak banget! Harganya pas di kantong mahasiswa tapi rasanya gak murahan. Risol ayamnya favorit!</p>
            </div>
        </div>
    </div>
</div>
<!-- Testimonial End -->

   <!-- Footer Start -->
    <div class="container-fluid footer text-white mt-5 pt-5 px-0 position-relative overlay-top">

        <!-- Baris Utama Footer -->
        <!-- Perubahan: Menggunakan 'justify-content-between' dan padding horizontal yang lebih kecil jika perlu -->
        <div class="row mx-0 pt-5 px-3 px-lg-5 mt-4 justify-content-between">

            <!-- Kolom 1: Kontak Kami -->
            <div class="col-lg-4 col-md-6 mb-5">
                <h4 class="text-white text-uppercase mb-4" style="letter-spacing: 3px;">Kontak Kami</h4>
                <p><i class="fa fa-map-marker-alt mr-2"></i>Jl. Harapan gg harapan 1, Pekanbaru</p>
                <p><i class="fa fa-phone-alt mr-2"></i>+62 895 1574 2694</p>
                <p class="m-0"><i class="fa fa-envelope mr-2"></i>kontak@BogengStore.com</p>
            </div>

            <!-- Kolom 2: Ikuti Kami -->
            <div class="col-lg-4 col-md-6 mb-5">
                <h4 class="text-white text-uppercase mb-4" style="letter-spacing: 3px;">Ikuti Kami</h4>
                <p>Dapatkan info promo terbaru dan varian rasa baru lewat sosial media kami.</p>
                <div class="d-flex justify-content-start">
                    <a class="btn btn-lg btn-outline-light btn-lg-square mr-2" href="#"><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-lg btn-outline-light btn-lg-square mr-2" href="#"><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-lg btn-outline-light btn-lg-square mr-2" href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a class="btn btn-lg btn-outline-light btn-lg-square" href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>

            <!-- Kolom 3: Jam Buka -->
            <div class="col-lg-4 col-md-6 mb-5">
                <h4 class="text-white text-uppercase mb-4" style="letter-spacing: 3px;">Jam Buka</h4>
                <div class="w-100"> <!-- Tambahan w-100 agar div ini mengambil lebar penuh kolom -->
                    <div class="d-flex justify-content-between mb-2">
                        <h6 class="text-white text-uppercase m-0">Senin - Jumat</h6>
                        <p class="m-0">08.00 - 20.00 WIB</p>
                    </div>
                    <div class="d-flex justify-content-between">
                        <h6 class="text-white text-uppercase m-0">Sabtu - Minggu</h6>
                        <p class="m-0">10.00 - 22.00 WIB</p>
                    </div>
                </div>
            </div>

            <!-- Kolom 4 (Tentang Kami) SUDAH DIHAPUS sesuai permintaan -->

        </div>

        <!-- Copyright -->
        <div class="container-fluid text-center text-white border-top mt-4 py-4 px-sm-3 px-md-5" style="border-color: rgba(256, 256, 256, .1) !important;">
            <p class="mb-2 text-white">Copyright &copy; <a class="font-weight-bold" href="{{ url('/') }}">BogengStore</a>. All Rights Reserved.</p>
            <p class="m-0 text-white">Designed by <a class="font-weight-bold" href="https://htmlcodex.com">HTML Codex</a> Distributed by <a href="https://themewagon.com" target="_blank">ThemeWagon</a></a></p>
        </div>
    </div>
    <!-- Footer End -->

<!-- Back to Top -->
<a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="fa fa-angle-double-up"></i></a>


<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
<script src="{{ asset('assets/lib/easing/easing.min.js') }}"></script>
<script src="{{ asset('assets/lib/waypoints/waypoints.min.js') }}"></script>
<script src="{{ asset('assets/lib/owlcarousel/owl.carousel.min.js') }}"></script>
<script src="{{ asset('assets/lib/tempusdominus/js/moment.min.js') }}"></script>
<script src="{{ asset('assets/lib/tempusdominus/js/moment-timezone.min.js') }}"></script>
<script src="{{ asset('assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js') }}"></script>

<!-- Contact Javascript File -->
<script src="{{ asset('assets/mail/jqBootstrapValidation.min.js') }}"></script>
<script src="{{ asset('assets/mail/contact.js') }}"></script>

<!-- Template Javascript -->
<script src="{{ asset('assets/js/main.js') }}"></script>


</body>

</html>
